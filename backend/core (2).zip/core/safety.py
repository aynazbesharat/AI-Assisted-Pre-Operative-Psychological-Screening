from fastapi import HTTPException

def validate_responses(questionnaire, responses):
    if len(questionnaire) != len(responses):
        raise HTTPException(status_code=400, detail="Number of responses does not match number of questions")

    for q, r in zip(questionnaire, responses):
        qtype = q.get("type")

        if qtype == "scale":
            if not isinstance(r, int):
                raise HTTPException(status_code=400, detail="Scale answer must be integer")
            if r < q["min"] or r > q["max"]:
                raise HTTPException(status_code=400, detail="Scale answer out of range")

        elif qtype == "yes_no":
            if r not in [0, 1]:
                raise HTTPException(status_code=400, detail="Yes/No answer must be 0 or 1")
