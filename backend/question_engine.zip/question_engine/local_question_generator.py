def generate_local_questions():
    return [
        {
            "id": 1,
            "question": "How anxious do you feel right now?",
            "type": "scale",
            "min": 0,
            "max": 10,
            "domain": "anxiety",
        },
        {
            "id": 2,
            "question": "Do you feel you need more information about the procedure?",
            "type": "yes_no",
            "min": None,
            "max": None,
            "domain": "info",
        },
        {
            "id": 3,
            "question": "How low or down do you feel right now?",
            "type": "scale",
            "min": 0,
            "max": 10,
            "domain": "mood",
        },
        {
            "id": 4,
            "question": "How confident do you feel in your coping skills right now?",
            "type": "scale",
            "min": 0,
            "max": 10,
            "domain": "coping",
        },
        {
            "id": 5,
            "question": "How safe and supported do you feel right now?",
            "type": "scale",
            "min": 0,
            "max": 10,
            "domain": "safety",
        },
    ]
