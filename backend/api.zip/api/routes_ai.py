from fastapi import APIRouter
from schemas.models import AIChatRequest, AIChatResponse

router = APIRouter(prefix="/api/ai", tags=["ai"])


@router.post("/chat", response_model=AIChatResponse)
def ai_chat(payload: AIChatRequest):
    # keep your existing AI logic here
    return {
        "answer": "OK"
    }
