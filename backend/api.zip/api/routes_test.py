from fastapi import APIRouter
from schemas.models import QuestionnaireItem
from question_engine.local_question_generator import generate_local_questions

router = APIRouter(prefix="/api", tags=["test"])


@router.get("/test/questionnaire", response_model=list[QuestionnaireItem])
def get_test_questionnaire():
    return [
        {"id": 1, "question": "How anxious do you feel right now?", "type": "scale", "min": 0, "max": 10},
        {"id": 2, "question": "Do you feel you need more information about the procedure?", "type": "yes_no"},
    ]

